#!/bin/sh
../basho_bench/basho_bench priv/basho_bench_eredis_list_int.config
make results
open tests/current/summary.png
